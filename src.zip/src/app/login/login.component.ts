import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ComponentService } from '../service/component.service';
import { Login } from '../models/login.model';
import { UserService } from '../user/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //@ViewChild('msg') msg: ElementRef<HTMLInputElement>;

  constructor(private sharingService: ComponentService, private userService: UserService, private router: Router) {

  }

  log: Login = new Login();
  loginvar: any;
  message: any;
  stat: any;

  login(): void {
    if (this.log.username == undefined || this.log.username == "" || this.log.password == undefined || this.log.password == "") {
      console.log("6")
      this.router.navigateByUrl('/login');
      this.stat = false;
      this.message = "Enter credentials.";
    }
    else {
      this.userService.loginUser(this.log)
        .subscribe(data => {
          this.loginvar = data;
          if (this.loginvar['error'] == "error") {
            console.log("5")
            this.stat = false;
            this.message = "Some Error with the login. Please try later.";
            this.router.navigateByUrl('/login');
          }

          else if (this.loginvar['success'] == "success") {
            console.log("4")
            this.sharingService.setLoginData(this.loginvar['user']);
            this.router.navigateByUrl('/login_user');
          }

          else {
            console.log("1")
            this.stat = false;
            this.message = "Invalid Credentials.";
            this.router.navigateByUrl('/login');
          }
        });
    }
  };

  ngOnInit() {
    if (this.sharingService.getStatus() == "true") {
      this.stat = false;
      this.message = "Invalid Credentials.";
      console.log("2")
    }
    else {
      this.stat = true;
    }
  }

}
