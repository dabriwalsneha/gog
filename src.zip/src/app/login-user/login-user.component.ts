import { Component, OnInit } from '@angular/core';
import { ComponentService } from '../service/component.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  constructor(private router: Router , private sharingService: ComponentService) { }

  login: any;
  welcome:boolean;

  title = 'Government of Gujarat';

  logout(){
    this.router.navigateByUrl('/login');
  }

  ngOnInit() {
    this.welcome = this.sharingService.getWel();

    this.login = this.sharingService.getLoginData();
  }

}
