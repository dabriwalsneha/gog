import { Component, OnInit } from '@angular/core';
import { ComponentService } from '../service/component.service';
import { Router } from '@angular/router';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  constructor(private router: Router , private userService: UserService, private sharingService: ComponentService) { }

  login: any;
  welcome:boolean;
  loginvar : any;

  title = 'Government of Gujarat';

  logout(){
    this.router.navigateByUrl('/login');
  }

  ngOnInit() {

    this.userService.loginUser(this.sharingService.getUser())
      .subscribe(data => {
        this.loginvar = data;
        console.log(this.loginvar['user'])
        this.login = this.loginvar['user'];
      });
    this.welcome = this.sharingService.getWel();

    
  }

}
