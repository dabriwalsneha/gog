export class City {

    id:number;
    cid:number;
    cname:String;

    constructor()
    {
        
    }
}
