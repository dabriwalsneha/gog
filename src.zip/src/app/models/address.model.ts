export class AddressJson {

    aid: number;
    houseNo: string;
    steetNo: string;
    city:string;
    country:string;
  }
  