

export class Employee {

    id: number;
    firstName: string;
    lastName: string;
    //addr: Address;

    addr:any=[];
  }
  