import { Employee } from './emp.model';

export class Address {

    id: number;
    __Adrs___hno: string;
    __Adrs___city: string;
    __Adrs___state:string;
    employee: Employee;
  }
  