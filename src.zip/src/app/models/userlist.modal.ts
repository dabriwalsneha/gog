export class UserList {
    userList : any = [];
    count : number;
}