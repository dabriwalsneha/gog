export class Country {

    id:number;
    cname:string;

    constructor(){
        
    }

}