import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserComponent } from './user/user.component';
import {AddUserComponent} from './user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { LoginComponent } from './login/login.component';
import { GetidComponent } from './getid/getid.component';
import { AddressComponent } from './address/address.component';

const routes: Routes = [
  { path:"", pathMatch:"full", redirectTo:"login"},
  
  {path: 'edit', component: EditUserComponent},
  { path: 'login', component: LoginComponent},
  { path: 'login_user', component: LoginUserComponent,
  children:[
    { path: 'users', component: UserComponent, outlet: 'user' },
    { path: 'add_user', component: AddUserComponent, outlet: 'user'},
    { path: 'gog', component: AddressComponent, outlet: 'user' },
    { path: 'getid', component: GetidComponent, outlet: 'user' }
  ]
}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
