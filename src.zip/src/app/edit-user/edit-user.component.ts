import { Component, OnInit } from '@angular/core';
import { User } from '../models/user.model';
import { UserService } from '../user/user.service';
import { ComponentService } from '../service/component.service'

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  constructor(private userService: UserService, private sharingService:ComponentService) { }

  user: User = new User();

  toUserslist = [];
  temptouserList=[];
  fromUserslist = ["Engineer", "Senior Engineer", "Technical Lead", "Manager", "Analyst"];

  ngOnInit() {
    this.user = this.sharingService.getData();
    var str_array: string[] = this.user.designation.toString().split(',');
    this.toUserslist = str_array;
    for(let i of this.toUserslist) {
      let temp: string = i.toString();
      const index : number = this.fromUserslist.indexOf(temp);
      this.fromUserslist.splice(index,1);
    }  
  }

createList(user, button1 : HTMLButtonElement, btnval : string, button2 : HTMLButtonElement){
  this.temptouserList=[];
  var str_array: string[] = user.toString().split(',');
  this.temptouserList = str_array;

  if(btnval == "button1"){
  button1.disabled = false;
  button2.disabled = true;
  }
  else{
    button1.disabled = true;
  button2.disabled = false;
  }
}


updateToList(){
  this.user.designation = "";
for(let i of this.temptouserList) {
  this.toUserslist.push(i); 
}
this.user.designation = this.toUserslist.toString();
for(let i of this.temptouserList) {
  let temp: string = i.toString();
  const index : number = this.fromUserslist.indexOf(temp);
  this.fromUserslist.splice(index,1);
}  
  this.temptouserList=[];
}

removeFromList(){
  this.user.designation = "";
  for(let i of this.temptouserList) {
  this.fromUserslist.push(i); 
}
for(let i of this.temptouserList) {
  let temp: string = i.toString();
  const index : number = this.toUserslist.indexOf(temp);
  this.toUserslist.splice(index,1);
}  
this.user.designation = this.toUserslist.toString();
  this.temptouserList=[];
}
  
city = ["Select one", "Delhi", "Greater Noida", "Noida", "Gurugram"];

  createUser(): void {
    this.userService.createUser(this.user)
        .subscribe( data => {
          alert("User created successfully.");
          
        });
  };

}
