import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';


import { User } from '../models/user.model';
import { UserService } from './user.service';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { City } from '../models/city.model';
import { Country } from '../models/country.model';

@Component({
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  countries :Country[];
  cities:City[];

  ngOnInit(){
    this.userService.getCountries().subscribe(
      data=>this.countries=data  
   );
  }



  user: User = new User();

  //  private baseUrl = 'http://localhost:8080/api/customers';
  private baseUrl = 'http://localhost:8080/user-portal/api/addperson';

  isEnabled = false;

  constructor(private http: HttpClient, private router: Router, private userService: UserService) {

  }

  response: any;

  fromUserslist = [
    "Engineer",
    "Senior Engineer",
    "Technical Lead",
    "Manager",
    "Analyst"
  ];

  toUserslist = [
  ];
  tempFrom = [];
  name: 'abc';

  temptouserList = [];
  //  index=_.findIndex(this.users, function(o) { return o.user == 'barney'; });

  onChangeCountry(countryId){
  
    if(!countryId)
    {
      this.cities=null;
      this.cities=null;
    }  
    else{

  this.userService.getCities(countryId).subscribe(
    data=>this.cities=data
  );
  this.cities=null;
}
}


  createList(user, button1: HTMLButtonElement, btnval: string, button2: HTMLButtonElement) {
    this.temptouserList = [];
    var str_array: string[] = user.toString().split(',');
    this.temptouserList = str_array;

    if (btnval == "button1") {
      button1.disabled = false;
      button2.disabled = true;
    }
    else {
      button1.disabled = true;
      button2.disabled = false;
    }

  }


  updateToList() {
    this.user.designation = "";
    for (let i of this.temptouserList) {
      this.toUserslist.push(i);
    }
    this.user.designation = this.toUserslist.toString();
    for (let i of this.temptouserList) {
      let temp: string = i.toString();
      const index: number = this.fromUserslist.indexOf(temp);
      this.fromUserslist.splice(index, 1);
    }
    this.temptouserList = [];
  }

  removeFromList() {
    this.user.designation = "";
    for (let i of this.temptouserList) {
      this.fromUserslist.push(i);
    }
    for (let i of this.temptouserList) {
      let temp: string = i.toString();
      const index: number = this.toUserslist.indexOf(temp);
      this.toUserslist.splice(index, 1);
    }
    this.user.designation = this.toUserslist.toString();
    this.temptouserList = [];
  }

  city = ["Select one", "Delhi", "Greater Noida", "Noida", "Gurugram"];

  createUser() {
    this.user.status = false;
    //alert(this.user.firstname)
    if (this.user.lastname == undefined || this.user.firstname == undefined || this.user.email == undefined) {
      alert("Enter all Details!")
    } else {

      this.userService.createUser(this.user)
        .subscribe(data => {
          this.response = data;
          console.log(this.response)
          if (this.response['success'] == "success") {
            alert("User created successfully.");
            this.router.navigateByUrl('/login_user');
          }
          else {
            alert("Please check with the entered details.");
          }
        });
    }
  };

}
