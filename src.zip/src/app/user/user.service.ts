import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { User } from '../models/user.model';
import { Login } from '../models/login.model';
import { Employee } from '../models/emp.model';
import { City } from '../models/city.model';
import { Country } from '../models/country.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserService {

  idsForApprove:any=[];
  Empl: Employee;

  constructor(private http:HttpClient) {}

  private addUserUrl = 'http://localhost:8080/user-portal/api/addperson';
  private loginUserURL = 'http://localhost:8080/user-portal/api/loginUser'
  //private userUrl = 'http://localhost:8080/user-portal/api/getNAUser';
  private userUrl = 'http://localhost:8080/user-portal/api/getUser';
  private approveUserUrl = 'http://localhost:8080/user-portal/api/approveUser';
  private approveUserParamUrl = 'http://localhost:8080/user-portal/api/approveUserParam';

  private addEmpUrl = 'http://localhost:8080/user-portal';
  

  private getEmpById = 'http://localhost:8080/user-portal/api/getEmpByID';
  private getempdetails = 'http://localhost:8080/user-portal/api/getEmpByID';


  getCountriesURL='http://localhost:8080/user-portal/api/countries';
  getCitiesURL='http://localhost:8080/user-portal/api/cities';

  //private userUrl = '/api';

  public getUsers() {
    console.log(this.userUrl);
    return this.http.get<User[]>(this.userUrl);
  }

  public deleteUser(user) {
    console.log(this.userUrl + "/"+ user.id);
    return this.http.delete(this.userUrl + "/"+ user.id);
  }

  public updateUser(idsForApprove) {
    return this.http.post<Int32Array[]>(this.approveUserUrl,idsForApprove);
  }

  public updateUserbyParam(usersforapprove) {
    console.log("dsfdsfdsf");
    return this.http.post<User[]>(this.approveUserParamUrl,usersforapprove);
  }

  public  createUser(user) {
    return this.http.post(this.addUserUrl,user);
  }

  public loginUser(log) {
    return this.http.post(this.loginUserURL, log);
  }

  public onFormSubmit(formaddarray,myfname,mylname) {
    console.log("dsfdsfdsf");
    
   //this.firstname = "myname";
   //this.Empl.firstName="ewrewr";
   //console.log(this.Empl.firstName);

   this.Empl = {
     id:0,
     firstName:myfname,
     lastName:mylname,
     addr: formaddarray.value
   }

   console.log(this.Empl.firstName);
   console.log(this.Empl.lastName);
   console.log(formaddarray.value);
   console.log("Ola1");
   console.log(this.Empl);
   console.log("Ola1");
    return this.http.post<Employee>(this.addEmpUrl+"/api/addEmployee_bkp",this.Empl);
  }

public postidData(id:any){
  console.log("ID get is "+ id)
  return  this.http.post<Employee>(this.getempdetails, id);
}


public getCountries()
{
  return this.http.get<Country []>(this.getCountriesURL)  
}


getCities(countryId:number)
{
console.log("Inside service");
  return this.http.get<City []>(this.getCitiesURL+"/"+countryId)
}

}
