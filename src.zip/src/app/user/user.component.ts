import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {SelectionModel} from '@angular/cdk/collections';
import { User } from '../models/user.model';
import { UserService } from './user.service';
import { identifierModuleUrl } from '@angular/compiler';
import { ComponentService } from '../service/component.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  displayedColumns: string[] = ['id', 'firstname', 'lastname', 'email', 'contact', 'age', 'city',
    'gender', 'designation', 'status', 'approve'];

    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;

    

  users: User[];
  usersforapprove: any = [];
  idsForApprove: any = [];
  dataSource: MatTableDataSource<User>;
  selection = new SelectionModel<User>(true, []);
  

  constructor(private router: Router, private userService: UserService, private sharingService: ComponentService) {    
  }
  

  ngOnInit() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data;
        this.dataSource = new MatTableDataSource<User>(this.users);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
      
  };

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    console.log(this.selection.selected.values)
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  deleteUser(user: User): void {
    this.userService.deleteUser(user)
      .subscribe(data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  updateUser(user: User): void {
    this.idsForApprove = [];
    for (let i of this.users) {
      if (i.selector) {
        this.idsForApprove.push(i.id);
      }
    }
    this.userService.updateUser(this.idsForApprove)
      .subscribe(data => {
        this.idsForApprove = data;
      });
  };

  editUser(user: User) {
    this.sharingService.setData(user);
    this.router.navigateByUrl('/edit');
  }

  toggleVisibility(e: User) {
    this.usersforapprove.push(e);
    console.log(this.usersforapprove)
  }

  updateUserbyParam(user: User): void {
    this.userService.updateUserbyParam(this.usersforapprove)
      .subscribe(data => {
        this.usersforapprove = data;
        alert("User Approved successfully.");
      });
  };

}