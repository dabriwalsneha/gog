package com.example.demo.service;


import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

//import com.main.IFMS.service.User;

@Service("userService")
public interface MainService 
{
	String create(User user);
	HashMap<String, String> login(Login login);
	//User create(User user);
	
	void updateStatus(List<User> users);
	
	User findUser(int uid);
	
	List<String> findAllFirstName();

	String deleteUser(int id);
	
    //List<User> findUserbyStatus(int stat);
    
    List<User> findAll();
	
    List<User> findUserbyStatus(boolean stat);    
    
    void addEmployee(Employee emp,List<Address> addr);
    
    Employee findEmpById(int eid);

}
